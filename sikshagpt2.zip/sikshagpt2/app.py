from flask import Flask, render_template, request, jsonify
from groq import Groq

app = Flask(__name__)

# 🔑 Paste your Groq API Key here
client = Groq(api_key="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")

@app.route("/")
def home():
    return render_template("index.html")

@app.route("/ask", methods=["POST"])
def ask_ai():
    data = request.get_json()
    user_question = data.get("question")

    try:
        # Changed to the active model: llama-3.3-70b-versatile
        chat_completion = client.chat.completions.create(
            messages=[
                {
                    "role": "system",
                    "content": "You are a helpful assistant. Always respond in Gujarati language."
                },
                {
                    "role": "user",
                    "content": user_question,
                }
            ],
            model="llama-3.3-70b-versatile",
        )

        ai_answer = chat_completion.choices[0].message.content

    except Exception as e:
        print(f"GROQ ERROR: {e}")
        ai_answer = "AI સર્વર હાલમાં વ્યસ્ત છે. કૃપા કરીને થોડીવાર પછી ફરી પ્રયાસ કરો."

    return jsonify({"answer": ai_answer})

if __name__ == "__main__":
    app.run(debug=True)