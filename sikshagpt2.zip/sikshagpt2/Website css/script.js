// ===============================
// 🔐 AUTHENTICATION FUNCTIONS
// ===============================
function isAuthenticated() {
  return localStorage.getItem("phish_user") !== null;
}

function logout() {
  localStorage.removeItem("phish_user");
}

// ===============================
// 📩 CONTACT FORM FUNCTIONS
// ===============================
function saveContactReport(report) {
  const reports = JSON.parse(localStorage.getItem("phish_reports") || "[]");
  reports.push(report);
  localStorage.setItem("phish_reports", JSON.stringify(reports));
  alert("✅ Report saved locally!");
}

function renderSavedReports() {
  const container = document.getElementById("saved-list");
  const list = document.getElementById("reports");
  const reports = JSON.parse(localStorage.getItem("phish_reports") || "[]");

  list.innerHTML = "";

  if (reports.length === 0) {
    list.innerHTML = "<li>No saved reports found.</li>";
  } else {
    reports.forEach((r) => {
      const li = document.createElement("li");
      li.innerHTML = `
        <strong>${r.name}</strong> (${r.email})<br>
        <em>${new Date(r.date).toLocaleString()}</em><br>
        ${r.message}
      `;
      list.appendChild(li);
    });
  }

  container.classList.remove("hidden");
}

// ===============================
// 🧠 QUIZ SECTION (REAL SCORE)
// ===============================

const quizData = [
  {
    question: "What is phishing?",
    options: [
      "A technique for catching fish online",
      "A cyberattack that tricks users into revealing sensitive information",
      "A method to speed up the internet",
      "A type of antivirus software"
    ],
    correct: 1
  },
  {
    question: "What should you check before clicking a link?",
    options: [
      "The color of the text",
      "The sender’s email and URL domain",
      "If it looks fancy",
      "If it’s short"
    ],
    correct: 1
  },
  {
    question: "What should you do if you suspect a phishing email?",
    options: [
      "Reply immediately to verify it",
      "Click the link to test it",
      "Report it to your IT/security team",
      "Ignore and delete it quietly"
    ],
    correct: 2
  },
  {
    question: "Which of the following is a sign of phishing?",
    options: [
      "Professional email from HR",
      "Urgent request for password or OTP",
      "System update notification",
      "Welcome email from your company"
    ],
    correct: 1
  },
  {
    question: "What’s the best protection method against phishing?",
    options: [
      "Two-factor authentication (2FA)",
      "Using only one password everywhere",
      "Sharing login details with friends",
      "Ignoring all emails"
    ],
    correct: 0
  }
];

function initQuiz() {
  const questionEl = document.getElementById("question");
  const optionsEl = document.getElementById("options");
  const nextBtn = document.getElementById("next-btn");
  const resultEl = document.getElementById("result");

  if (!questionEl || !optionsEl) return; // Only run on quiz page

  let current = 0;
  let score = 0;
  let answered = false;

  // Load a question
  function loadQuestion() {
    answered = false;
    const q = quizData[current];
    questionEl.textContent = `${current + 1}. ${q.question}`;
    optionsEl.innerHTML = "";

    q.options.forEach((opt, i) => {
      const btn = document.createElement("button");
      btn.className = "btn option-btn";
      btn.textContent = opt;
      btn.addEventListener("click", () => selectOption(i));
      optionsEl.appendChild(btn);
    });

    nextBtn.disabled = true;
  }

  // Handle answer click
  function selectOption(index) {
    if (answered) return;
    answered = true;

    const q = quizData[current];
    const buttons = document.querySelectorAll(".option-btn");

    buttons.forEach((b, i) => {
      if (i === q.correct) {
        b.style.background = "#2e7d32"; // green for correct
        b.style.color = "#fff";
      } else if (i === index) {
        b.style.background = "#c62828"; // red for wrong
        b.style.color = "#fff";
      }
      b.disabled = true;
    });

    // ✅ Only increase score if answer is correct
    if (index === q.correct) {
      score++;
    }

    nextBtn.disabled = false;
  }

  // Next button
  nextBtn.addEventListener("click", () => {
    current++;
    if (current < quizData.length) {
      loadQuestion();
    } else {
      showResult();
    }
  });

  // Final result
  function showResult() {
    questionEl.style.display = "none";
    optionsEl.style.display = "none";
    nextBtn.style.display = "none";

    resultEl.classList.remove("hidden");
    resultEl.innerHTML = `
      <h3>Your Score: ${score} / ${quizData.length}</h3>
      <p>${
        score === quizData.length
          ? "🎉 Excellent! You identified all phishing tricks correctly!"
          : score >= quizData.length / 2
          ? "👍 Good job! But stay alert for phishing attempts."
          : "⚠️ You need to be more cautious with suspicious emails."
      }</p>
    `;
  }

  loadQuestion();
}

// Initialize quiz on page load
document.addEventListener("DOMContentLoaded", initQuiz);
